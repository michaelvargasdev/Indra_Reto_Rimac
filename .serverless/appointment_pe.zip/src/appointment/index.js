"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const env_1 = require("../utils/env");
const handler = async (_event, _context) => {
    if (_event.body !== null) {
        const event = _event;
        const body = JSON.parse(`${event.body}`);
        const snsPublisher = new aws_sdk_1.SNS();
        var paramsPublisher = {
            Message: JSON.stringify(body),
            TopicArn: env_1.SNS_SCHEDULE_ARN_PE,
        };
        console.log(paramsPublisher, 'paramsPublisher');
        const responseSns = await snsPublisher.publish(paramsPublisher).promise();
        console.log(responseSns, 'ResponseSns');
        responseSns.MessageId;
    }
    else {
        const event = _event;
        for (const message of event.Records) {
        }
    }
    return {
        statusCode: 200,
        body: JSON.stringify({
            ok: true
        })
    };
};
exports.handler = handler;
//# sourceMappingURL=index.js.map