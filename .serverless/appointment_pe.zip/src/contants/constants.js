"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COUNTRY_ISO = void 0;
exports.COUNTRY_ISO = {
    PE: 'PE',
    CL: 'CL'
};
//# sourceMappingURL=constants.js.map